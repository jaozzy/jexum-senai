$(document).ready(function () {
    console.log('carregou essa porra');
    $('form').on('submit', function (event) {
        event.preventDefault();

        if (($('#titulo').val() != '') && ($('#descricao').val() != '')) {

            const emailData = {
                titulo: $('#titulo').val(),
                descricao: $('#descricao').val()
            }

            $.ajax({
                type: "POST",
                url: "/System/ValidarReport",
                data: JSON.stringify(emailData),
                success: function (response) {
                    console.log(response)
                },
                error: function (error) {
                    console.log(error)
                }
            });

        }

    });
});