$(document).ready(function () {

    console.log('oi');

    $('form').on('submit', function (event) {

        event.preventDefault();

        console.log('form enviado');

        const nome = $('#nome').val();
        const email = $('#email').val();
        const senha = $('#senha').val();
        const cargo = $('#cargo').val();

        if (nome != '' && email != '' && senha != '' && !isNaN(cargo)) {

            let usuario = {
                nome: nome,
                email: email,
                senha: senha,
                cargo: parseInt(cargo),
            }

            $.ajax({
                type: "POST",
                url: "/User/ValidarLogin",
                data: usuario,
                success: function (result) {
                    if (result.success === true) {
                        localStorage.setItem('logged', 'true');
                        window.location.href = result.redirectUrl;
                    } else {
                        console.log('Login falhou');
                    }
                },
                error: function () {
                    console.log('Erro durante a requisição AJAX');
                }
            });

            console.log('requisição ajax efetuada');

        } else {
            alert('Preencha os campos corretamente!');
        }

    });
});